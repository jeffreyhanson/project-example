# R2jags
R2jags: Using R to Run 'JAGS'
